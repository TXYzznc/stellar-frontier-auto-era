# 03 · 世界 HUD

> 本文档可单独交给 UI 设计师和生图 AI。效果图、专属素材和状态切图必须标记 `NEW-GEN`，不得使用旧截图或旧素材作为参考。

## 0. 效果图编号

`MOCK-UI-03`；本页效果图是布局、素材组合和状态验收证据，不是运行时切图。

## 1. 界面概述

- **页面族**：世界 HUD
- **页面 ID**：HudStatus, HudTracker, HudAlerts, HudNavigation, HudSave
- **当前 Form**：`FieldHudForm/FieldHudResidentForm`
- **设计目标**：世界可见区域优先，常驻信息不遮挡对象详情
- **当前页面来源**：Docs/GameDesign/03-玩家体验/界面规格/03-世界HUD/HudAlerts.md、Docs/GameDesign/03-玩家体验/界面规格/03-世界HUD/HudNavigation.md、Docs/GameDesign/03-玩家体验/界面规格/03-世界HUD/HudSave.md、Docs/GameDesign/03-玩家体验/界面规格/03-世界HUD/HudStatus.md、Docs/GameDesign/03-玩家体验/界面规格/03-世界HUD/HudTracker.md
- **视觉专属职责**：资源摘要、能源摘要、时间、任务、保存状态、导航标记。
- **页面运行原则**：世界继续运行；动态文字、数值、进度、算法连线和状态摘要由程序/TMP绘制，图片只提供结构、插画槽和无文字装饰。

## 2. 真实布局与技术来源

参考分辨率 1920×1080；Prefab `Assets/Game/Prefabs/UI/Hud/FieldHudForm.prefab`；脚本 `Assets/Game/Scripts/AutoEra/UI/FieldHudForm.cs`

| 节点 | 类型 | contract sizeDelta | anchorMin | anchorMax |
|---|---|---|---|---|
| `Grp_PageHost` |  | [0.0, 0.0] | `[0.0, 0.0]` → `[1.0, 1.0]` |

### 2.1 设计区域

- 画布：1920×1080；SafeArea 以内保留 24px 外边距。
- 页面主容器：使用深灰蓝 `UI/Surface`；浅色信息卡使用 `UI/Card`；当前焦点使用 `UI/Action`。
- 视觉阅读顺序：标题/当前对象 → 核心摘要 → 列表或详情 → 操作 → 警报/辅助说明。
- 效果图中的尺寸必须以 contract 和对应 prefab-layout 为准；无法从 contract 读取的工程值标记 `TODO-TECH`，不由图片猜测。

## 3. 元素与数据槽位

| 区域 | 内容 | 视觉层级 | 动态/静态 | 状态槽 |
|---|---|---|---|---|
| 顶部标题区 | 页面名、返回、关闭、当前对象摘要 | H1/焦点 | 动态文字 | normal/loading/error |
| 主列表/导航区 | 页面族内项目、页签、筛选、分类 | H2/中 | 动态 Item | empty/selected/disabled |
| 详情/工作区 | 当前对象、状态、来源、成本、容量或规则 | H2/中高 | 动态文字＋新插画槽 | normal/warning/blocked |
| 操作区 | 主要动作、次动作、取消/返回 | 最高交互层 | 控件 | normal/hover/pressed/disabled |
| 辅助反馈 | Toast、警报、进度、空态 | 条件层 | 程序/VFX | info/success/warning/danger |

**本族专属内容**：资源摘要、能源摘要、时间、任务、保存状态、导航标记。

## 4. 中文效果图提示词（可直接复制）

```text
原创工业二次元科幻游戏 UI 页面，清线赛璐璐，平整色块，硬边阴影，少量高光线，1920×1080 正面构图，深灰蓝页面底，浅色信息卡，少量橙色焦点，锐角切角与模块化网格，成熟商业游戏 UI 完成度。
页面族：世界 HUD。展示页面 ID：HudStatus, HudTracker, HudAlerts, HudNavigation, HudSave。核心视觉目标：世界可见区域优先，常驻信息不遮挡对象详情。
布局采用标题区、主列表/导航区、详情工作区、底部操作区和条件反馈区；信息层级明确，留出 SIMHEI 动态文字槽，不生成可读文字、数字或 Logo。
专属视觉对象：资源摘要、能源摘要、时间、任务、保存状态、导航标记。状态板同时展示：normal、warning、critical、saving。所有面板、图标、角标和插画均为原创新设计，不复制参考游戏版式，不使用旧项目截图。
```

## 5. English prompt

```text
Original anime industrial science-fiction game UI, clean cel-shaded digital art, flat color masses, hard-edged shadows, sparse highlight lines, 1920x1080 front view, deep blue-gray background, light information cards, restrained orange focus accents, sharp corner cuts and modular grid, polished commercial game UI.
Page family: 世界 HUD; page IDs: HudStatus, HudTracker, HudAlerts, HudNavigation, HudSave; visual focus: 世界可见区域优先，常驻信息不遮挡对象详情. Compose a title/header area, navigation or list area, detail/work area, action area and conditional feedback area. Leave empty slots for runtime SIMHEI text and values; do not render readable text, numbers or logos.
Use original assets only. Do not copy any existing game layout, old project screenshot, icon or font.
```

## 6. 页面专属素材清单

| ID | 文件名 | 素材 | 源尺寸 | 状态级文件 | 生成方式 | 依赖 | 存放路径 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| `SCR-03-001` | `scr-03-001@512x128.png` | 页面标题/专属角标 | 512×128 | normal/active/disabled | 生图 | UI-MASTER-001/002/003/004 | Assets/Game/Sprites/UI/Pages/03-世界HUD/ |
| `SCR-03-002` | `scr-03-002@512x288.png` | 页面主图或对象缩略图 | 512×288 | normal/empty/alert | 生图 | UI-MASTER-001/002/003/004 | Assets/Game/Sprites/UI/Pages/03-世界HUD/ |
| `SCR-03-003` | `scr-03-003@1024x512.png` | 页面详情卡装饰 | 1024×512 | normal/warning/blocked | 生图 | UI-MASTER-001/002/003/004 | Assets/Game/Sprites/UI/Pages/03-世界HUD/ |
| `SCR-03-004` | `scr-03-004@96x96.png` | 页面状态徽记 | 96×96 | normal/success/warning/danger | 生图 | UI-MASTER-001/002/003/004 | Assets/Game/Sprites/UI/Pages/03-世界HUD/ |
| `SCR-03-005` | `scr-03-005@640x360.png` | 空态/说明插画槽 | 640×360 | empty/locked | 生图 | UI-MASTER-001/002/003/004 | Assets/Game/Sprites/UI/Pages/03-世界HUD/ |
| `UI-RUNTIME` | `ui-runtime@512x512.png` | 本族动态数值、连线或进度 | — | runtime | 程序绘制 | TMP/状态合同 | —（程序绘制，不入 Sprite） |

## 7. 交互状态

| 控件 | 状态 | 视觉变化 | 非颜色反馈 |
|---|---|---|---|
| 页面主按钮 | normal/hover/pressed/disabled | 橙色焦点、按下内阴影、禁用降对比 | 角标/位置/图标 |
| 列表 Item | normal/selected/disabled/empty | 浅色卡片明暗和左侧标记 | 选中角框、焦点线 |
| 异常反馈 | info/success/warning/danger | 语义色边条和局部高光 | 图标、标题槽、形状 |
| 加载/等待 | loading/pending | 短脉冲或静态阶段标记 | 进度、状态词槽 |

## 8. 引用的共用素材

UI-MASTER-001/002/003/004

页面文档只引用四个母版 ID；共用提示词维护在 `界面设计文档/共用素材/` 的母版文档中。

## 共用母版与 Logo 引用

页面共用壳统一引用 `UI-MASTER-001`（容器）、`UI-MASTER-002`（控件）、`UI-MASTER-003`（语义图标）和 `UI-MASTER-004`（反馈轨道），状态差异按共用素材文档的状态表执行，不另画近似母版。

页面出现品牌标识时只引用 LOGO-REF-001，并从 Assets/Game/Sprites/UI/Brand/Logo/ 上传对应的已冻结 PNG：
- LOGO-001-icon：logo-001-icon@256x256.png，只用于小尺寸徽记。
- LOGO-002-lockup：logo-002-lockup@1024x256.png，用于启动页、页眉和登录/存档页。
- LOGO-003-title：logo-003-title@1920x480.png，用于大标题和宣传构图。
三张图都使用中文主字标“异星拓荒”：“异”表达异星基地舱门入口，“星”保留三层同心星核负空间，“拓”嵌入机械拓展臂与输送轨道，“荒”形成三层地层台阶并由琥珀色开拓线收束。必须保持轨道环右上 30° 缺口、字形骨架、基线、比例和透明负空间完全一致。Frontier Foundry 只是英文品牌名，不能自行混入中文主 Logo。未出现品牌标识时不得临时添加 Logo。

## 9. 验收要点

- [ ] 效果图与当前 Form/contract 的区域和层级一致。
- [ ] 标题、当前对象、主操作和警报的焦点顺序清楚。
- [ ] 页面专属素材没有偷换成其它族的近似图标。
- [ ] `FieldHudDetailForm` 的详情层高于 `FieldHudResidentForm`（适用时）。
- [ ] 空态、禁用、等待、错误和成功至少覆盖本族代表状态。
- [ ] 所有动态文字、数字、连线和进度不烘焙进切图。
- [ ] 所有图像从零生成，保留提示词、模型、种子和源文件指纹。

## 10. 返工条件

结构偏离 contract、出现旧素材痕迹、复制参考游戏版式、出现乱码/伪造 Logo、状态只靠颜色、把效果图当运行时切图，均退回重新设计。

## AI 单文档生成合同（可独立投喂）

### 共同输入与身份控制

本文件本身就是完整生成合同。输入只包括本文件和（画面需要 Logo 时）已经生成的 Logo PNG。Logo 不是重新设计对象：只使用上传的 Assets/Game/Sprites/UI/Brand/Logo/ PNG，保持轨道环右上 30° 缺口、三层同心星核、中文“异星拓荒”字形骨架、舱门/星核/机械臂/地层主题细节、比例、基线、负空间和透明背景完全一致；Frontier Foundry 不得自行加入；未明确写“出现 Logo”的画面不得自行添加 Logo。不要引用旧截图、旧模型、参考游戏界面或未登记资源。

### 视觉风格

- 原创工业二次元清线赛璐璐：平整色块、硬边阴影、2–4px 结构线、少量冷白高光线；轮廓清楚，避免照片级材质和柔焦。
- 形体采用 12°/30°/45° 的规整切角和模块化边界；相同母版的外轮廓、透视、锚点和安全区必须保持一致。
- 画面信息层级按“主体轮廓 → 状态装饰 → 留字/留数值槽 → 次要纹理”排列，不能用装饰抢主操作焦点。

### 配色 Token 与使用比例

- `UI/Background #111923`：页面底、遮罩和未激活区域，占画面约 55%–70%。
- `UI/Surface #1B2633`：主面板和导航底，占约 15%–25%。
- `UI/Card #2B3745`、`UI/CardRaised #364657`：卡片、列表、悬停和聚焦层，占约 8%–15%。
- `UI/TextPrimary #E9EEF2`、`UI/TextSecondary #AEBCC7`：只作为留字槽对比参考，图片中不生成可读文字。
- `UI/Action #E68A37`、`UI/Focus #F0A24B`：操作、焦点和确认强调，合计不超过画面 8%。
- `UI/Success #67C28A`、`UI/Warning #D8B15A`、`UI/Danger #D75E63`：状态色只作辅助，必须同时有形状、刻线、缺口、纹理或位置变化。
- `UI/Alien #79A9C7`：异星数据或传感器信息，禁止大面积铺满。

颜色只负责语义辅助；normal、hover、pressed、selected、disabled、warning、danger、empty 等状态必须另外加入位置、轮廓、刻线、断口、斜线纹理、内缩或外伸等非颜色差异。

### 内容与构图要求

- 先按本文件资源表逐条生成，不合并条目，不新增未登记的按钮、图标、文字、数字、徽章或装饰。
- 容器和控件中心保留运行时文字/数值槽；图标使用统一母版壳，语义由几何形状、数量和方向表达。
- 页面类画面采用 1920×1080 安全区，四周留 24px；透明切图按表格尺寸正面输出，九宫格边角不可进入中心拉伸区。
- 需要 Logo 时，直接使用上传的 Logo PNG，保持原始比例，不把 Logo 烘焙进其它切图。

### 技术输出

- 透明 PNG，sRGB，边缘无白边和半透明脏边；不生成可读文字、数字、百分比、连线、动态粒子或程序遮罩。
- 文件名、尺寸和 `Assets/Game/Sprites/` 目标目录严格使用本文件资源表；每个状态独立导出并保持画布、Pivot 和安全区一致。

### 负面提示词

`旧项目截图、参考游戏 UI、复制现成图标、照片、写实渲染、柔焦、渐变、霓虹光晕、均匀黑描边、可读文字、乱码、伪造数字、百分比、Logo 重绘、额外徽章、状态只换颜色、裁切、白边、背景不透明、透视漂移、边角进入拉伸区`

### 直接提示词

`03-世界HUD，原创工业二次元清线赛璐璐游戏 UI，深蓝灰 #111923/#1B2633/#2B3745 基础，冷白 #E9EEF2 信息层，琥珀 #E68A37/#F0A24B 少量焦点，绿色 #67C28A、黄色 #D8B15A、红色 #D75E63 仅作状态辅助，规整切角、模块化边界、硬边阴影、少量高光线、透明 PNG、中心留运行时文字和数值槽；严格按本文资源表生成，状态必须有轮廓/刻线/缺口/纹理等非颜色差异，无文字无数字无旧截图无 Logo 重绘。`

### 交付验收

- [ ] 每个表格条目都有独立文件，数量和顺序与文档一致。
- [ ] 同一母版所有状态的外轮廓、画布和锚点完全一致。
- [ ] 状态在灰度缩略图中至少有两种非颜色差异。
- [ ] 目标尺寸、透明背景、文件名和路径全部符合表格。

### 风格

原创工业二次元清线赛璐璐；平整色块、硬边阴影、少量结构高光，保持本文件的形体、镜头和色彩合同，不使用照片、柔焦或参考游戏复制。

### 输出

按本文件登记的尺寸、视图、透明度、文件名和目标路径交付；透明切图使用干净 PNG，效果图使用 1920×1080，sRGB，无裁切、白边和背景污染。

### 构图

主体优先，前景/中景/背景或标题区/主体区/反馈区按本文层级排列；四周保留安全区，接口、作业点、状态装饰和运行时留槽必须完整可见，不用空背景或无关装饰填充画面。
